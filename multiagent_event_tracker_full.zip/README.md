MultiAgent Event Tracker - Full Project
This ZIP contains a Flask backend and a React frontend skeleton. See backend/README and frontend/README for setup steps.